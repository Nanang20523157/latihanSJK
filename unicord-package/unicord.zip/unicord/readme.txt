=== Unicord ===
Author: Themezinho
Requires at least: 5.0
Tested up to: 5.5.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creative Portfolio for Freelancers & Agencies Theme	


== Description ==

Unicord is a high quality portfolio theme for digital agencies and freelancers. If you want to present your works in best way soo with Unicord you can create your own website very easily and quickly.






== Changelog ==

= 1.0 =
* Initial Release

