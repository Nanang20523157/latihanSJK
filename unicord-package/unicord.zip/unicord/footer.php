<?php
$footer_logo = unicord_get_option( 'footer_logo' );

if( !$footer_logo ) {
  $footer_logo = get_template_directory_uri() . '/images/logo.png';
}
$show_social_icons = unicord_get_option( 'footer_show_social_links' );
$show_cta = unicord_get_option( 'show_call_to_action' );
$copyright = unicord_get_option( 'footer_copyright_text' );

if( !$copyright ) {
  $copyright = __( '© 2021 Unicord | Creative Portfolio for Freelancers & Agencies', 'unicord' );
}

$footer_styling = '';

if( unicord_get_option( 'footer_bg_image' ) ) {
  $footer_styling .= 'background: url(' . esc_url( unicord_get_option( 'footer_bg_image' ) ) . ') center no-repeat;';
}
if( unicord_get_option( 'footer_bg_color' ) ) {
  $footer_styling .= 'background-color: ' . unicord_get_option( 'footer_bg_color' ) . ';' ;
}
?>

<footer class="footer" <?php if( $footer_styling !== '' ) { echo 'style="' . esc_attr( $footer_styling ) . '"'; } ?>>
    <div class="container wow fadeIn">
	    <?php if( $footer_logo ) { ?>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                <img src="<?php echo esc_url( $footer_logo ); ?>" alt="<?php bloginfo( 'name' ); ?>">
            </a>
	    <?php } ?>

	    <?php if( $show_cta ) { ?>
	        <h2><?php echo wp_kses_post( unicord_get_option( 'footer_cta_tagline_title' ) ); ?></h2>

	        <?php if( unicord_get_option( 'footer_cta_subtitle' ) ) { ?>
                <h5><?php echo wp_kses_post( unicord_get_option( 'footer_cta_subtitle' ) ); ?></h5>
            <?php } ?>
        <?php } ?>

        <?php if( $show_social_icons ) {
	        $social_media = unicord_get_option( 'social_media' );

	        if( count( $social_media ) ) {
		        ?>
                <ul>
                    <?php foreach( $social_media as $social ) { ?>
                        <li><a href="<?php echo esc_url( $social['url'] ); ?>"><i class="<?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
                    <?php } ?>
                </ul>
		        <?php
	        }
        } ?>
	    <?php if( $copyright !== ''  ) { ?>
            <span><?php echo wp_kses_post( $copyright ); ?></span>
	    <?php } ?>
    </div>
    <!-- end container -->
</footer>

<?php
if( unicord_get_option( 'enable_hamburger_menu_click_sound' ) ) {
    $audio_link = get_template_directory_uri() . '/audio/link.mp3';
    $hover_link = get_template_directory_uri() . '/audio/hover.mp3';
    ?>
    <audio id="link" src="<?php echo esc_url( $audio_link ); ?>" preload="auto"></audio>
    <audio id="hover-audio" src="<?php echo esc_url( $hover_link ); ?>" preload="auto"></audio>
<?php }
?>

<?php wp_footer(); ?>

</body>
</html>