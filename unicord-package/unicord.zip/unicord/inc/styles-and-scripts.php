<?php

if( ! function_exists( 'unicord_google_fonts_url' ) ) {
	/*
	* Register Google Font Family
	*/
	function unicord_google_fonts_url() {
		$fonts_url = '';

		/*
		Translators: If there are characters in your language that are not supported
		by chosen font(s), translate this to 'off'. Do not translate into your own language.
		 */
		$fjalla_one = _x( 'on', 'Fjalla One font: on or off', 'unicord' );
		$poppins = _x( 'on', 'Poppins font: on or off', 'unicord' );

		if ( 'off' !== $fjalla_one || 'off' !== $poppins ) {

			$font_families = array();

			if ( 'off' !== $fjalla_one ) {
				$font_families[] = 'Fjalla One';
			}

			if ( 'off' !== $poppins ) {
				$font_families[] = 'Poppins:300,400,500,600,700,900';
			}

			$f_query_args = array(
				'family' => urlencode( implode( '|', $font_families ) ),
				'subset' => urlencode( 'latin-ext' ),
			);
			$fonts_url = add_query_arg( $f_query_args, '//fonts.googleapis.com/css' );

		}

		return esc_url_raw( $fonts_url );
	}

}

if ( ! function_exists( 'unicord_enqueue_styles_and_scripts' ) ) {
	/**
	 * This function enqueues the required css and js files.
	 *
	 * @return void
	 */
	function unicord_enqueue_styles_and_scripts() {
		/**
		 * Enqueue css files.
		 */
		wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
		wp_enqueue_style( 'animate', get_template_directory_uri() . '/css/animate.min.css' );
		wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/css/fancybox.min.css' );
		wp_enqueue_style( 'swiper', get_template_directory_uri() . '/css/swiper.min.css' );
		wp_enqueue_style( 'bootsrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
		wp_enqueue_style( 'unicord-google-font', unicord_google_fonts_url(), array(), '1.0.0' );
		wp_enqueue_style( 'unicord-main-style', get_template_directory_uri() . '/css/style.css' );
		wp_enqueue_style( 'unicord-stylesheet', get_stylesheet_uri() );
		wp_add_inline_style( 'unicord-stylesheet', unicord_dynamic_css() );

		/**
		 * Enqueue javascript files.
		 */

		wp_enqueue_script( 'comments', get_template_directory_uri() . '/js/comments.js', array(), false, false );
		wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'swiper', get_template_directory_uri() . '/js/swiper.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/js/fancybox.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'wow', get_template_directory_uri() . '/js/wow.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'isotope', get_template_directory_uri() . '/js/isotope.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'tilt', get_template_directory_uri() . '/js/tilt.jquery.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'typewriter', get_template_directory_uri() . '/js/jquery.typewriter.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'tween-max', get_template_directory_uri() . '/js/TweenMax.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'imagesloaded');
		wp_enqueue_script( 'particles', get_template_directory_uri() . '/js/particles.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'parallax', get_template_directory_uri() . '/js/jquery.parallax.min.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'motion-blur', get_template_directory_uri() . '/js/motion.blur.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'unicord-scripts', get_template_directory_uri() . '/js/scripts.js', array( 'jquery' ), false, true );
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		$data = array(
			'pre_loader_typewriter' => [],
			'audio_source' => '',
			'enable_hamburger_menu_click_sound' => false
		);

		if( unicord_get_option( 'enable_preloader' ) ) {
			$typewriter_text = [];
			$text_rotater = unicord_get_option( 'pre_loader_text_rotater' );
			if( $text_rotater ) {
				foreach ( $text_rotater as $rotater ) {
					$typewriter_text[] = esc_html( $rotater['title'] );
				}
			}
			$data['pre_loader_typewriter'] = $typewriter_text;
		}
		if( unicord_get_option( 'enable_background_music' ) ) {
			$data['audio_source'] = esc_url( unicord_get_option( 'background_music_file' ) );
		}
		if( unicord_get_option( 'enable_hamburger_menu_click_sound' ) ) {
			$data['enable_hamburger_menu_click_sound'] = esc_url( unicord_get_option( 'enable_hamburger_menu_click_sound' ) );
		}

		$comment_data = array(
			'name'      => esc_html__( 'Name is required', 'unicord' ),
			'email'     => esc_html__( 'Email is required', 'unicord' ),
			'comment'   => esc_html__( 'Comment is required', 'unicord' ),

		);

		wp_localize_script( 'unicord-scripts', 'data', $data );
		wp_localize_script( 'comments', 'data', $comment_data );
	}

	add_action( 'wp_enqueue_scripts', 'unicord_enqueue_styles_and_scripts', 10 );
}

if( !function_exists( 'unicord_dynamic_css' ) ) {
	function unicord_dynamic_css() {

		$styles = '';
		if( unicord_get_option( 'enable_dynamic_color' ) ) {

			$site_color = ( unicord_get_option( 'theme_color' ) ) ? unicord_get_option( 'theme_color' ) : '#33a16e';
			$body_bg_color = ( unicord_get_option( 'body_background_color' ) ) ? unicord_get_option( 'body_background_color' ) : '#131314';

			$styles ="
				.site-works,
				body,
				main{
					background: {$body_bg_color} !important;
				}
				a:hover,
				.navigation-menu .inner ul li .dropdown li a:hover,
				.social-media li a:hover,
				.navbar .languages a:hover,
				.header .gallery-thumbs .swiper-slide a,
				.filter-bar .works-filter li a.current,
				.filter-bar .works-filter li a:hover,
				.case-details .case-navbar ul li a:hover,
				.features-content a,
				.news .post .post-content .post-categories li a:hover,
				.news .post .post-content .post-title a:hover,
				.news .post .post-content h5,
				.news .post .post-content .post-link,
				.widget-area .widget .widget-title,
				.widget-area .widget .widget-title a,
				.say-hello .map-link,
				.say-hello #contact label.error,
				.footer ul li a:hover
				{
					color: {$site_color} !important;
				}
				
				.dots-menu:hover .pix
				{
				  background-color: {$site_color} !important;
				}
				
				.modal .modal-dialog .modal-content .close,
				.preloader,
				.preloader .typewriter #typewriter-suffix,
				.preloader .loadbar,
				.transition-overlay .green-layer,
				.navigation-menu .green-layer,
				.navigation-menu .inner ul li a:before,
				.unicord-horizontal-nav .menu li .sub-menu,
				.unicord-horizontal-nav .menu li .children,
				.video-hero a:hover,
				.particles-mask .inner a:hover,
				.features-content a:before,
				.introduction p span:after,
				.news .post .post-content .social-share li a,
				.news .post .post-content blockquote,
				.news .post .post-content .post-link:before,
				.widget-area .widget .widget-title:after,
				.widget-area .widget_tag_cloud .tagcloud a:hover
				{
					background: {$site_color} !important;
				}
				
				.preloader .loadbar {
				  box-shadow: 0px 0px 10px {$site_color} !important;
				}
				
				.unicord-horizontal-nav .menu li .sub-menu:after,
				.unicord-horizontal-nav .menu li .children:after
				{
				  border-color: transparent transparent transparent #33a16e;
				}
				
				.particles-mask .inner a:hover,
				.video-hero a:hover,
				.widget-area .widget_tag_cloud .tagcloud a:hover
				{
				  border-color: {$site_color} !important;
				}
				
				.filter-bar .works-filter li a.current{
				  border-bottom: 2px solid {$site_color} !important;
				}
				
				.say-hello #contact input.error,
				.say-hello #contact textarea.error
				{
				  border: 2px solid {$site_color} !important;
				}
			";
		}

		return $styles;
	}
}

add_action( 'init', 'unicord_dynamic_css' );