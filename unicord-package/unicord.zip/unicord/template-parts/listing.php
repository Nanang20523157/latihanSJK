<?php
ob_start();
if( has_excerpt() ) {
	$post_content = the_excerpt();
} else {
	$post_content = the_content();
}
$post_content = ob_get_clean();

$layout_type = ( unicord_get_option( 'archive_layout' ) ) ? unicord_get_option( 'archive_layout' ) : 'one_col';
$strip_content = ( unicord_get_option( 'archive_strip_content' ) ) ? unicord_get_option( 'archive_strip_content' ) : 'yes';

if( $strip_content !== 'no' ){
	$post_content = preg_replace( '~\[[^\]]+\]~', '', $post_content );
	$post_content = strip_tags( $post_content );
	$post_content = unicord_get_the_post_excerpt( $post_content, 300 );
}

$wrapper_class = array( 'wow', 'fadeIn', 'blog-post' );

?>
<div id="post-<?php the_ID(); ?>" <?php post_class( $wrapper_class ); ?>>
    <figure class="post-image">
        <?php if( unicord_get_post_thumbnail_url() ) { ?>
            <img src="<?php echo esc_url( unicord_get_post_thumbnail_url() ); ?>" alt="<?php the_title_attribute(); ?>">
        <?php } ?>

    </figure>
    <div class="post-content">
        <?php unicord_posted_by(); ?>

        <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <?php unicord_post_tags(); ?>
        <small class="post-date"><?php echo get_the_date(); ?></small>
        <div class="post-intro">
	        <?php echo wp_kses_post( $post_content ); ?>

        </div>

        <div class="clearfix"></div>
        <a href="<?php the_permalink(); ?>" class="post-link"><?php echo esc_html__( 'READ MORE', 'unicord' ); ?></a>
    </div>
</div>
