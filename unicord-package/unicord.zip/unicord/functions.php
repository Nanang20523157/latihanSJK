<?php
/**
 * Unicord functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Unicord
 */

if ( ! function_exists( 'unicord_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function unicord_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Anchor, use a find and replace
		 * to change 'unicord' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'unicord', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		//add_image_size( 'unicord-post-thumb-small', 1400, 691, true );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );
	}
endif;
add_action( 'after_setup_theme', 'unicord_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function unicord_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'unicord_content_width', 640 );
}
add_action( 'after_setup_theme', 'unicord_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function unicord_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'unicord' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'unicord' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'unicord_widgets_init' );

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Enqueue styles and scripts.
 */
require_once get_template_directory() . '/inc/styles-and-scripts.php';

/**
 * Register nav menus
 */
require_once get_template_directory() . '/inc/nav-menus.php';

/**
 * Custom menu walker.
 */
require_once get_template_directory() . '/inc/class.custom-menu-walker.php';

require_once get_template_directory() . '/inc/tgm.php';

if ( ! function_exists( 'unicord_get_the_post_excerpt' ) ) {
	/**
	 * This function makes excerpt for the post.
	 *
	 * @param integer $limit of charachers
	 * @return string
	 */
	function unicord_get_the_post_excerpt( $string, $limit = 70, $more = '...', $break_words = false ) {
		if($limit == 0) return '';

		if( mb_strlen( $string, 'utf8' ) > $limit ) {
			$limit -= mb_strlen( $more, 'utf8' );

			if( !$break_words ) {
				$string = preg_replace('/\s+\S+\s*$/su', '', mb_substr($string, 0, $limit + 1, 'utf8'));
			}

			return '<p>' . mb_substr( $string, 0, $limit, 'utf8' ) . $more . '</p>';
		} else {

			return '<p>' . $string . '</p>';
		}
	}

}

if( ! function_exists( 'unicord_posted_date_with_tags' ) ) {

	function unicord_posted_date_with_tags() {

		echo sprintf( __( 'Posted %s', 'unicord' ), get_the_date('j F Y') );

		$tags = get_the_tags();
		if ( false !== $tags ) {
			foreach ( $tags as $tag ) {
				$link = get_tag_link( $tag->term_id );
				$data[] = '<a href="' . $link . '">' . $tag->name . '</a>';
			}

			echo ' | ' . implode( ', ', $data );
		}
	}
}

if( ! function_exists( 'unicord_move_comment_field_to_bottom' ) ) {
	function unicord_move_comment_field_to_bottom( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;

		return $fields;
	}

	add_filter( 'comment_form_fields', 'unicord_move_comment_field_to_bottom' );
}

if( ! function_exists( 'unicord_bootstrap_comment' ) ) {
	/**
	 * Custom callback for comment output
	 *
	 */
	function unicord_bootstrap_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;

		$comment_link_args = array(
			'add_below'  => 'comment',
			'respond_id' => 'respond',
			'reply_text' => esc_html__('Reply', 'unicord'),
			'login_text' => esc_html__('Log in to Reply', 'unicord'),
			'depth'      => 1,
			'before'     => '',
			'after'      => '',
			'max_depth'  => 5
		);
		?>
		<?php if ( $comment->comment_approved == '1' ): ?>
            <li class="comment">
                <figure class="comment-avatar"><?php echo get_avatar( $comment ); ?></figure>
                <div class="comment-content">
                    <h4><?php comment_author_link() ?></h4>
                    <p><?php comment_text() ?></p>
                    <small> <?php comment_date() ?></small>
					<?php
					comment_reply_link( $comment_link_args );
					?>
                </div>
            </li>
		<?php endif;
	}

}

if( ! function_exists( 'unicord_get_option' ) ) {

	function unicord_get_option( $slug ) {
		if( function_exists( 'get_field' ) ) {
			return get_field( $slug, 'option' );
		}

		return false;
	}
}

if( ! function_exists( 'unicord_get_field' ) ) {

	function unicord_get_field( $slug, $post_id = 0 ) {
		if( function_exists( 'get_field' ) ) {
			return get_field( $slug, $post_id );
		}

		return false;
	}
}

if( ! function_exists( 'unicord_pagination' ) ) {
	/**
	 * Custom Pagination
	 */
	function unicord_pagination( $animate = false, $masonry = false ) {
		global $wp_query, $wp_rewrite;

		$wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
		$pagination = array(
			'base' 		=> add_query_arg('paged','%#%'),
			'format' 	=> '',
			'total' 	=> $wp_query->max_num_pages,
			'current' 	=> $current,
			'prev_text' => __( 'Previous', 'unicord' ),
			'next_text' => __( 'Next', 'unicord' ),
			'type' 		=> 'list'
		);
		if( $wp_rewrite->using_permalinks() )
			$pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );

		if( !empty($wp_query->query_vars['s']) )
			$pagination['add_args'] = array( 's' => get_query_var( 's' ) );

		$class = '';
		if( $animate ) {
			$class .= 'wow fadeInUp ';
		}
		if( $masonry ) {
			$class .= 'masonry-cols ';
		}
		if( $animate )
			echo "<div class='pagination col-12 " . esc_attr( $class ) . "'>";
		echo paginate_links( $pagination );
		echo "</div>";
	}
}


if( ! function_exists( 'unicord_get_post_thumbnail_url' ) ) {
	/**
	 * Get Post Thumbnail URL
	 */
	function unicord_get_post_thumbnail_url() {
		if( get_the_post_thumbnail_url() ) {
			return get_the_post_thumbnail_url( get_the_ID(), 'unicord-post-thumb-small' );
		}

		return false;
	}
}

if( ! function_exists( 'unicord_get_page_title' ) ) {

	function unicord_get_page_title() {
		$title = '';

		if ( is_category() ) {
			$title = single_cat_title( '', false );
		} elseif ( is_tag() ) {
			$title = single_term_title( "", false ) . esc_html__( 'Tag', 'unicord' );
		} elseif ( is_date() ) {
			$title = get_the_time( 'F Y' );
		} elseif ( is_author() ) {
			$title = esc_html__( 'Author:', 'unicord' ) . ' ' . esc_html( get_the_author() );
		} elseif ( is_search() ) {
			$title = esc_html__( 'Search Result', 'unicord' );
		} elseif ( is_404() ) {
			$title = esc_html__( 'Page not found', 'unicord' );;
		} elseif ( is_archive() ) {
			$title = esc_html__( 'Archive', 'unicord' );
		} elseif ( is_home() || is_front_page() ) {
			if ( is_home() && ! is_front_page() ) {
				$title = esc_html( single_post_title( '', false ) );
			} else {
				$title = ( unicord_get_option( 'archive_blog_title' ) ) ? esc_html( unicord_get_option( 'archive_blog_title' ) ) : esc_html__( 'Blog', 'unicord' );
			}
		} else {
			global $post;
			if ( ! empty( $post ) ) {
				$id = $post->ID;
				$title = esc_html( get_the_title( $id ) );
			} else {
				$title = esc_html__( 'Post not found.', 'unicord' );
			}
		}

		return $title;
	}

}

if( ! function_exists( 'unicord_get_archive_description' ) ) {
	function unicord_get_archive_description() {
		$description = '';

		if( is_category() || is_tag() || is_author() || is_post_type_archive() || is_archive() ) {
			$description = get_the_archive_description();
		}

		return $description;
	}
}
if( ! function_exists( 'unicord_render_page_header' ) ) {

	function unicord_render_page_header( $type ) {

		$show_header = true;
		$background_type = 'color';
		$background_video_url = '';
		$header_style = '';
		$header_title = '';
		$header_description = '';
		$enable_social_icons = true;
		$enable_scroll_down = true;

		switch ( $type ){
			case 'page' :
				$show_header = false;
				if( unicord_get_field( 'show_page_header' ) !== 'no' ) {
					$show_header = true;
					$background_type = unicord_get_field( 'header_background_type');

					if( unicord_get_field( 'header_title_type') === 'custom' ) {
						$header_title = unicord_get_field( 'header_title');
					}
					else {
						$header_title = get_the_title();
					}

					if( $background_type === 'color' ) {
						$header_bg_color = unicord_get_field( 'header_bg_color' ) ? unicord_get_field( 'header_bg_color' ) : '#131314';
						$header_style = 'background-color: ' . $header_bg_color . ';';
					}
					else {
						$background_video_url = unicord_get_field( 'header_video' );
					}

					$header_description = unicord_get_field( 'description' );
					$enable_social_icons = ( unicord_get_field( 'disable_social_icons' ) ) ? false : true;
					$enable_scroll_down = ( unicord_get_field( 'disable_scroll_down' ) ) ? false : true;

				}

				break;
			case 'portfolio' :
				$background_type = unicord_get_field( 'header_background_type');

				$header_title = get_the_title();

				$header_bg_color = unicord_get_field( 'header_bg_color' ) ? unicord_get_field( 'header_bg_color' ) : '#000';
				$header_style = 'background-color: ' . $header_bg_color . ';';

				if( unicord_get_field( 'header_video' ) ) {
					$background_video_url = unicord_get_field( 'header_video' );
				}

				$header_description = unicord_get_field( 'description' );
				$enable_social_icons = ( unicord_get_field( 'disable_social_icons' ) ) ? false : true;
				$enable_scroll_down = ( unicord_get_field( 'disable_scroll_down' ) ) ? false : true;

				break;
			case 'archive':
			case 'single':
			case 'frontpage':
				$header_description = unicord_get_archive_description();
				if( $type == 'single' ) {
					$header_title = unicord_get_option( 'archive_blog_title' ) ? unicord_get_option( 'archive_blog_title') : __('News', 'unicord');
				}
				else{
					$header_title = unicord_get_page_title();
				}
				$background_type = unicord_get_option( 'archive_header_bg_type' );
				if( $background_type === 'color' ) {
					$header_bg_color = unicord_get_option( 'archive_header_bg_color' ) ? unicord_get_option( 'archive_header_bg_color' ) : '#131314';
					$header_style = 'background-color: ' . $header_bg_color .';';
				}
				else {
					$background_video_url = unicord_get_option( 'archive_header_bg_video' );
				}

				break;
			case '404':
				$header_title = unicord_get_page_title();
				$background_type = unicord_get_option( 'page_404_header_bg_type' );
				if( $background_type === 'color' ) {
					$header_bg_color = unicord_get_option( 'page_404_header_bg_color' ) ? unicord_get_option( 'page_404_header_bg_color' ) : '#131314';
					$header_style = 'background-color: ' . $header_bg_color .';';
				}
				else {
					$background_video_url = unicord_get_option( 'page_404_header_bg_video' );
				}
				break;
			case 'search':
				$header_title = unicord_get_page_title();
				$header_description = sprintf( __('Search result for: %s ', 'unicord' ), '<span>' . get_search_query() . '</span>' );
				$background_type = unicord_get_option( 'search_header_bg_type' );
				if( $background_type === 'color' ) {
					$header_bg_color = unicord_get_option( 'search_header_bg_color' ) ? unicord_get_option( 'search_header_bg_color' ) : '#131314';
					$header_style = 'background-color: ' . $header_bg_color .';';
				}
				else {
					$background_video_url = unicord_get_option( 'search_header_bg_video' );
				}
				break;
		}

		if( $show_header ) {
			$autoplay = ( unicord_get_option( 'autoplay_background_video' ) ) ? unicord_get_option( 'autoplay_background_video' ) : false;
			?>
            <header class="page-header" <?php if ( $header_style !== '' ) { echo 'style="' . esc_attr( $header_style ) . '"'; } ?>>
				<?php if ( $background_video_url ) { ?>
                    <div class="video-bg">
                        <video src="<?php echo esc_url( $background_video_url ); ?>" muted <?php if( $autoplay ) { echo 'autoplay'; } ?> loop></video>
                    </div>
				<?php } ?>
                <!-- end video-bg -->
                <div class="inner">
                    <h2 data-text="<?php echo esc_attr( $header_title ); ?>"><?php echo wp_kses_post( $header_title ); ?></h2>
					<?php if( $header_description !== '' ) { ?>
                        <div class="clearfix"></div>
                        <p><?php echo wp_kses_post( $header_description ); ?></p>
					<?php } ?>
                </div>
                <!-- end inner -->
				<?php
				if( $enable_social_icons ) {
					$social_media = unicord_get_option( 'social_media' );
					if ( $social_media ) {
						?>
                        <ul class="social-media">
							<?php foreach ( $social_media as $social ) { ?>
                                <li><a href="<?php echo esc_url( $social['url'] ); ?>"
                                       title="<?php echo esc_attr( $social['title'] ); ?>"><i
                                                class="fa <?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
							<?php } ?>
                        </ul>
						<?php
					}
				}
				?>
				<?php
				if( !unicord_get_option( 'enable_scroll_down' ) ) {
					$enable_scroll_down = false;
				}
				if( $enable_scroll_down ) {
					$scroll_down_label = unicord_get_option( 'scroll_down_label' );
					if( $scroll_down_label ) {
						?>
                        <div class="scroll-down"><b><?php echo esc_html( $scroll_down_label ); ?></b><span></span></div>
						<?php
					}
				} ?>
            </header>

			<?php
		}

	}
}


if( ! function_exists( 'unicord_post_tags' ) ) {

	function unicord_post_tags() {

		$tags = get_the_tags();
		if ( false !== $tags ) {
			?>
            <ul class="post-categories">
				<?php
				foreach ( $tags as $tag ) {
					$link = get_tag_link( $tag->term_id );
					?>
                    <li><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $tag->name ); ?></a></li>
					<?php
				}
				?>
            </ul>
			<?php
		}
	}
}




function unicord_import_files() {
	return array(
		array(
			'import_file_name'             => 'Unicord Demo Import',
			'import_file_url' 				=> 'http://unicord.themezinho.net/import/demo-data.xml',
			'import_notice'                => __( 'After you import this demo, you will have to setup the theme option separately.', 'unicord' ),
			'preview_url'                  => 'https://unicord.themezinho.net',
		),
	);

}
add_filter( 'pt-ocdi/import_files', 'unicord_import_files' );





add_action( 'vc_before_init', 'unicord_wpbakery_roles' );
function unicord_wpbakery_roles() {
  $vc_list = array('page','post','portfolio');
  vc_set_default_editor_post_types($vc_list);
  vc_editor_set_post_types($vc_list);
}



function unicord_after_import_setup() {
	// Assign menus to their locations.
	$main_menu = get_term_by( 'name', 'Main menu', 'nav_menu' );
	set_theme_mod( 'nav_menu_locations', array(
			'header' => $main_menu->term_id,
		)
	);

	// Assign front page and posts page (blog page).
	$front_page_id = get_page_by_title( 'Start' );
	$blog_page_id  = get_page_by_title( 'News' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );

	if( function_exists( 'unicord_after_import' ) ) {
		unicord_after_import();
    }

}
add_action( 'pt-ocdi/after_import', 'unicord_after_import_setup' );
add_filter( 'pt-ocdi/regenerate_thumbnails_in_content_import', '__return_false' );
add_action( 'pt-ocdi/disable_pt_branding', '__return_true' );