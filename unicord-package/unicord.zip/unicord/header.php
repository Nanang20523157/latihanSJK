<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php
$nav_menu_type = unicord_get_option( 'nav_menu_type' );
$social_media = unicord_get_option( 'social_media' );
$logo = ( unicord_get_option( 'logo' ) ) ? unicord_get_option( 'logo' ) : get_template_directory_uri() . '/images/logo.png';
?>
<?php
if ( unicord_get_option( 'enable_preloader' ) ):
  $pre_loader_icon = ( unicord_get_option( 'pre_loader_icon' ) !== '' ) ? unicord_get_option( 'pre_loader_icon' ) : get_template_directory_uri() . '/images/preloader.gif';
$pre_loader_bg_custom_size = ( unicord_get_option( 'pre_loader_bg_size' ) !== '' ) ? unicord_get_option( 'pre_loader_bg_size' ) : '80px 80px';
$pre_loader_bg = ( unicord_get_option( 'pre_loader_wrapper_bg_color' ) !== '' ) ? unicord_get_option( 'pre_loader_wrapper_bg_color' ) : '#000000';
$style = 'background: url(' . esc_url( $pre_loader_icon ) . ') center no-repeat ' . esc_attr( $pre_loader_bg ) . ' ; background-size:' . esc_attr( $pre_loader_bg_custom_size ) . ' !important ';

?>
<div class="preloader">
  <div class="inner" style="<?php esc_attr( $style ); ?>">
    <div class="loader">
      <div class="trackbar">
        <div class="loadbar"></div>
      </div>
    </div>
    <!-- end loader -->
    <div class="holder"> <span class="typewriter" id="typewriter"></span> </div>
    <!-- end holder --> 
  </div>
  <!-- end inner --> 
</div>
<!-- end preloader -->
<div class="transition-overlay">
  <div class="green-layer"></div>
  <div class="black-layer"></div>
</div>
<!-- end transition-overlay -->
<?php endif; ?>
<nav class="navigation-menu">
  <div class="green-layer"></div>
  <div class="black-layer"></div>
  <div class="inner">
    <?php
    wp_nav_menu( array(
      'walker' => new Hamburger_Menu_Walker(),
      'container' => ''
    ) );
    ?>
    <?php if( unicord_get_option( 'menu_address' ) ) { ?>
    <address>
    <?php echo wp_kses_post( unicord_get_option( 'menu_address' ) ); ?>
    </address>
    <?php } ?>
  </div>
  <!-- end inner --> 
</nav>
<nav class="navbar">
  <div class="logo"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"> <img src="<?php echo esc_url( $logo ); ?>" alt="<?php bloginfo( 'name' ); ?>" /> </a> </div>
  <!-- .logo -->
  
  <?php
  if ( $nav_menu_type === 'hamburger' ):

    $nav_menu_label = ( unicord_get_option( 'nav_menu_label' ) != '' ) ? unicord_get_option( 'nav_menu_label' ) : __( 'MENU', 'unicord' );

  if ( unicord_get_option( 'show_email' ) ):
    ?>
  <div class="email-us"><?php echo esc_html( unicord_get_option( 'email_label' ) ); ?> <a href="mailto:<?php echo esc_attr( strip_tags( unicord_get_option( 'email_address' ) ) ); ?>"><?php echo wp_kses_post( unicord_get_option( 'email_address' ) ); ?></a></div>
  <?php endif; ?>
  <div class="sandwich-nav"> <b><?php echo esc_html( $nav_menu_label ); ?></b>
    <div class="sandwich-btn circle" id="sandwich-btn" data-dist="7"> <span></span> <span></span> </div>
    <!-- end sandwich-btn --> 
    
  </div>
  <?php
  else :
    ?>
  <div class="main-nav unicord-horizontal-nav">
    <?php
    wp_nav_menu( array(
      'theme_location' => 'header',
    ) );
    ?>
  </div>
  <div class="sandwich-nav sandwich-nav-mobile">
    <div class="sandwich-btn circle" id="sandwich-btn" data-dist="7"> <span></span> <span></span> </div>
    <!-- end sandwich-btn --> 
  </div>
  <?php  endif; ?>
</nav>
