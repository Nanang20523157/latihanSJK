<?php
/**
 * Template Name: Portfolio
 *
 */

get_header();
?>
    <?php unicord_render_page_header( 'page' ); ?>
<?php
$portfolio_columns = 'three-cols';

if( get_field( 'p_column' ) ) {
	$portfolio_columns = get_field( 'p_column' );
}
?>
<main>
    <section class="content-section site-works works <?php echo esc_attr( $portfolio_columns ); ?>">
	    <?php
	    $portfolio_tags = get_terms( 'portfolio_tag' );
	    $filter_term = false;
	    if( get_field( 'tags' ) && get_field( 'tags' ) > 0 ) {
		    $filter_term = true;
	    }
	    if( count( $portfolio_tags ) && $filter_term === false ) {
		    ?>
            <div class="container">
                <div class="filter-bar">
                    <div class="filter-btn">
                        <div class="dots-menu">
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                            <div class="pix"></div>
                        </div>
                        <!-- end dots-menu -->
                        <span><?php echo esc_html__( 'FILTER', 'unicord' ); ?></span>
                    </div>
                    <!-- end filter-btn -->
                    <ol class="works-filter">
                        <li><a href="javascript:void(0);" data-filter="*" class="current"><?php echo esc_html__( 'ALL', 'unicord' ); ?></a></li>
	                    <?php foreach ( $portfolio_tags as $tag ) {
		                    ?>
                            <li><a href="javascript:void(0);" data-filter=".<?php echo esc_attr( $tag->slug ); ?>"><?php echo esc_html( $tag->name ); ?></a></li>

		                    <?php
	                    }
	                    ?>
                    </ol>
                </div>
                <!-- end filter-bar -->
            </div>
            <!-- end container -->

		    <?php
		    $args = array (
			    'post_type'              => 'portfolio',
			    'posts_per_page'            => -1,
			    'meta_query' => array(
				    array(
					    'key'       => 'thumbnail_image',
					    'value'     => '',
					    'compare'   => '!='
				    )
			    )
		    );

		    if( $filter_term ) {
			    $args[ 'tax_query' ] = array(
				    array(
					    'taxonomy' => 'portfolio_tag',
					    'field' => 'id',
					    'terms' => array ( get_field( 'tags' ) )
				    )
			    );
		    }
		    $portfolio = new WP_Query( $args );

		    if ( $portfolio->have_posts() ) :
			    ?>
                <ul>
				    <?php
				    while ( $portfolio->have_posts() ) :
					    $portfolio->the_post();

					    $thumbnail_image = get_field( 'thumbnail_image' );
					    $terms = get_the_terms( $portfolio->post->ID, 'portfolio_tag' );

					    $term_classes = array();
					    $term_name = array();
					    if( $terms ) {
						    foreach( $terms as $term ) {
							    $term_classes[] = $term->slug;
							    $term_name[] = $term->name;
						    }
					    }

					    $term_classes = implode( ' ', $term_classes );
					    $term_name = implode( ',', $term_name );
					    ?>
                        <li class="wow fadeInUp <?php echo esc_attr( $term_classes ); ?>">
                            <figure data-tilt>
                                <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title_attribute(); ?>" class="thumb">
                                <figcaption>
								    <?php if( get_field( 'logo' ) ) { ?>
                                        <img src="<?php echo esc_url( get_field( 'logo' ) ); ?>" class="brand" />
								    <?php } ?>
                                    <h3><?php the_title(); ?></h3>

								    <?php if( $term_name !== '' ){ ?>
                                        <small><?php echo esc_html( $term_name ); ?></small>
								    <?php } ?>
                                    <a href="<?php the_permalink(); ?>"><?php echo esc_html__('CASE DETAILS', 'unicord'); ?></a> </figcaption>
                            </figure>
                        </li>
				    <?php
				    endwhile;
				    ?>
                </ul>
		    <?php
		    endif;
		    wp_reset_query();
		    ?>

		    <?php
	    } ?>

    </section>
</main>

<?php
get_footer();
