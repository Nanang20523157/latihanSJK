<?php
get_header();
?>

<?php unicord_render_page_header( 'portfolio' ); ?>

<?php
while ( have_posts() ) :
    the_post();
	?>
<main> 
    <section class="case-details">
		<?php the_content(); ?>
	</section>
	</main>
<?php endwhile; ?>

<?php
get_footer();
?>
