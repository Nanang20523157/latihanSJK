<?php
if ( !defined( 'ABSPATH' ) ) {
  die( '-1' );
}

class WPBakeryShortCode_ts_awards_box extends WPBakeryShortCode {

  protected function content( $atts, $content = null ) {

    extract( shortcode_atts( array(
      'title' => '',
      'details' => '',
    ), $atts ) );

    ob_start();

    $wrapper_class = '';
 $details = vc_param_group_parse_atts( $atts[ 'details' ] );
    ?>
<div class="awards-box">
  <h3><?php echo esc_html( $title ); ?></h3>
  <ul>
    <?php
    $new_accordion_value = array();
    foreach ( $details as $data ) {
      $new_line = $data;
      $new_line[ 'list' ] = isset( $new_line[ 'list' ] ) ? $new_line[ 'list' ] : '';
      $new_accordion_value[] = $new_line;
    }

    $idd = 0;
    foreach ( $new_accordion_value as $accordion ):
      $idd++;

    ?>
   
    <li> <?php echo wp_kses_post($accordion['list']);?> </li>
    <?php
    endforeach;
    wp_reset_query();
    ?>
  </ul>
</div>
<?php

return ob_get_clean();
}
}


vc_map( array(
  "base" => "ts_awards_box",
  "name" => __( 'Awards Box', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
  "content_element" => true,
  "category" => __( 'unicord' ),
  'params' => array(
    array(
      "type" => "textfield",
      "heading" => __( 'Title', 'unicord' ),
      "param_name" => "title",
      "group" => 'General',
    ),
    array(
      'type' => 'param_group',
      'param_name' => 'details',
      "group" => 'General',
      'heading' => __( 'List', 'themezinho' ),
      'params' => array(

        array(
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => __( "List", 'themezinho' ),
          "param_name" => "list",
          "value" => ""
        ),


      )
    ),
  ),
) );
