<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_section_title extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'		=> '',
			'tagline'		=> '',
			'animate_block'			=> 'false',
			'animation_type'		=> 'fadeIn',
			'animation_delay'		=> '',
		), $atts ) );
		
		ob_start();

		$wrapper_class = '';
		if( $animate_block == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}
		?>
        <div class="section-title <?php echo esc_attr( $wrapper_class ); ?>" <?php if( $animate_block == 'yes' && $animation_delay != '' ) { echo 'data-wow-delay="' . esc_attr( $animation_delay ) . '"'; } ?>>
			
			<h2><?php echo wp_kses_post( $title ); ?></h2>
			<h5><?php echo wp_kses_post( $tagline ); ?></h5>
           
       
        </div>

		<?php

		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_section_title",
	"name" 			    => __( 'Section Title', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Title', 'unicord' ),
			"param_name" 	=> 	"title",
			"group" 		=> 'General',
		),	
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Tagline', 'unicord' ),
			"param_name" 	=> 	"tagline",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate_block",
			"group" 		=> 'Animation',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"group" 		=> 'Animation',
			"value"			=>	motts_animations()
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Animation Delay', 'unicord' ),
			"param_name" 	=> 	"animation_delay",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"description"	=>	__( 'Animation delay set in second e.g. 0.6s', 'unicord' ),
			"group" 		=> 'Animation',
		)
	),
) );
