<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_client extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'	            => '',
			'logo'              => '',
			'animate'		    => 'no',
			'animation_type'    => '',
		), $atts ) );


		ob_start();

		$wrapper_class = '';
		if( $animate == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}

		$logo = wp_get_attachment_url( $logo );

		if( $logo ) {
		    ?>
            <div class="client-logo <?php echo esc_attr( $wrapper_class ); ?>">

                <figure>
                    <img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
                    <?php if( $title ) { ?>
                        <h6><?php echo esc_html( $title ); ?></h6>
                    <?php } ?>
                </figure>

            </div>
            <?php
        }
		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_client",
	"name" 			    => __( 'Client Logo', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Title', 'unicord' ),
			"param_name" 	=> 	"title",
			"description"	=>	"Feature Title",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Logo', 'unicord' ),
			"param_name" 	=> 	"logo",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate",
			"group" 		=> 'General',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate", 'value' => 'yes'),
			"group" 		=> 'General',
			"value"			=>	motts_animations()
		)
	),
) );
