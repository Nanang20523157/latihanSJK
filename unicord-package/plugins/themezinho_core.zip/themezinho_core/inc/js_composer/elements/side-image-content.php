<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_image_with_content extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'main_image'		            => '',
			'small_image'			        => '',
			'button_label'			        => '',
			'button_url'			        => '',
			'animate_block'			=> 'no',
			'animation_type'		=> '',
			'animation_delay'		=> '',
			'content_bg'		=> '',
			'content_position'		=> '',
		), $atts ) );
		$main_image_url = '';
		if ( $main_image != '') {
			$main_image_url = wp_get_attachment_url( $main_image );
		}

		$small_image_url = '';
		if ( $small_image != '') {
			$small_image_url = wp_get_attachment_url( $small_image );
		}
		ob_start();

		$wrapper_class = '';
		if( $animate_block == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}
		?>

        <div class="side-image-content">
            <div class="content">
				   <figure class="image wow fadeInLeft">
                    <img src="<?php echo esc_url( $small_image_url ); ?>" alt="Image" />
                </figure>
                <div class="inner <?php echo esc_attr( $wrapper_class ); ?>" <?php if( $animate_block == 'yes' && $animation_delay != '' ) { echo 'data-wow-delay="' . esc_attr( $animation_delay ) . '"'; } ?>>
	                <?php echo wpb_js_remove_wpautop( $content, true ); ?>
					<a href="<?php echo esc_attr( $button_url ); ?>"><?php echo esc_html( $button_label ); ?></a>
                </div>
                <!-- end content -->
            </div>
            <!-- end inner -->
        </div>

		<?php

		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_image_with_content",
	"name" 			    => __( 'Image With Content', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Main Image', 'unicord' ),
			"param_name" 	=> 	"main_image",
			"group" 		=> 'Image Section',
		),
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Small Image', 'unicord' ),
			"param_name" 	=> 	"small_image",
			"group" 		=> 'Image Section',
		),

		array(
			"type" 			=> 	"textarea_html",
			"heading" 		=> 	__( 'Content', 'unicord' ),
			"param_name" 	=> 	"content",
			"group" 		=> 'Content Section',
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Button Label', 'unicord' ),
			"param_name" 	=> 	"button_label",
			"group" 		=> 'Content Section',
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Button URL', 'unicord' ),
			"param_name" 	=> 	"button_url",
			"group" 		=> 'Content Section',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate_block",
			"group" 		=> 'Content Section',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"group" 		=> 'Content Section',
			"value"			=>	motts_animations()
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Animation Delay', 'unicord' ),
			"param_name" 	=> 	"animation_delay",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"description"	=>	__( 'Animation delay set in second e.g. 0.6s', 'unicord' ),
			"group" 		=> 'Content Section',
		),
		array(
			"type" 			=> 	"colorpicker",
			"heading" 		=> 	__( 'Background Color', 'unicord' ),
			"param_name" 	=> 	"content_bg",
			"group" 		=> 'Content Section',
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Position', 'unicord' ),
			"param_name" 	=> 	"content_position",
			"group" 		=> 'Content Section',
			"value"			=>	array(
				"Right"			=>		'right',
				"Left"			=>		'left',
			)
		),
	),
) );
