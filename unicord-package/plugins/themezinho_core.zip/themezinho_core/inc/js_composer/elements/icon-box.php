<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_feature extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'		            => '',
			'icon'			        => '',
			'feature_content'		=> '',
			'btn_visibility'		=> 'hide',
			'btn_label'		        => __( 'LEARN MORE', 'unicord' ),
			'btn_url'				=> '',
			'animate_block'			=> 'false',
			'animation_type'		=> 'fadeIn',
			'animation_delay'		=> '',
		), $atts ) );
		$icon_url = '';
		if ($icon != '') {
			$icon_url = wp_get_attachment_url( $icon );
		}
		ob_start();

		$wrapper_class = '';
		if( $animate_block == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}
		?>
        <div class="icon-box <?php echo esc_attr( $wrapper_class ); ?>" <?php if( $animate_block == 'yes' && $animation_delay != '' ) { echo 'data-wow-delay="' . esc_attr( $animation_delay ) . '"'; } ?>>
            <?php if( $icon_url != '' ){ ?>
                <img src="<?php echo esc_url( $icon_url ); ?>" alt="<?php echo esc_attr( $title ); ?>">
            <?php } ?>
            <h4><?php echo wp_kses_post( $title ); ?></h4>
            <?php echo wpb_js_remove_wpautop( $feature_content, true ); ?>
            <?php
            if( $btn_visibility === 'show' ){
            ?>
                <a href="<?php echo esc_url( $btn_url ); ?>"><?php echo esc_html( $btn_label ); ?></a>
            <?php } ?>
        </div>

		<?php

		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_feature",
	"name" 			    => __( 'Icon Box', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Title', 'unicord' ),
			"param_name" 	=> 	"title",
			"description"	=>	"Feature Title",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Icon', 'unicord' ),
			"param_name" 	=> 	"icon",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"textarea",
			"heading" 		=> 	__( 'Content', 'unicord' ),
			"param_name" 	=> 	"feature_content",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Button', 'unicord' ),
			"param_name" 	=> 	"btn_visibility",
			"group" 		=> 'General',
			"value"			=>	array(
				"Hide"			=>		'hide',
				"Show"			=>		'show',
			)
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Button URL', 'unicord' ),
			"param_name" 	=> 	"btn_url",
			"dependency" => array('element' => "btn_visibility", 'value' => 'show'),
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Button Label', 'unicord' ),
			"param_name" 	=> 	"btn_label",
			"dependency" => array('element' => "btn_visibility", 'value' => 'show'),
			"group" 		=> 'General',
		),

		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate_block",
			"group" 		=> 'Animation',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"group" 		=> 'Animation',
			"value"			=>	motts_animations()
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Animation Delay', 'unicord' ),
			"param_name" 	=> 	"animation_delay",
			"dependency" => array('element' => "animate_block", 'value' => 'yes'),
			"description"	=>	__( 'Animation delay set in second e.g. 0.6s', 'unicord' ),
			"group" 		=> 'Animation',
		)
	),
) );
