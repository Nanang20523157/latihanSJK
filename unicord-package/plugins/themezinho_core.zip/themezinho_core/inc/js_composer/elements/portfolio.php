<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_portfolio extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'total_count'		    => 8,
			'column'			    => 'three-cols',
		), $atts ) );

		$total_count = (int) $total_count;
		if( !is_int( $total_count ) ) {
			$total_count = 8;
		}
		ob_start();

		$args = array (
			'post_type'              => 'portfolio',
			'posts_per_page'            => $total_count,
			'meta_query' => array(
				array(
					'key'       => 'thumbnail_image',
					'value'     => '',
					'compare'   => '!='
				)
			)
		);
		$portfolio = new WP_Query( $args );

		if ( $portfolio->have_posts() ) :

			?>
            <div class="works <?php echo esc_attr( $column ); ?>">
                <ul>
				<?php
				$i = 1;
				while ( $portfolio->have_posts() ) :
					$portfolio->the_post();

					$thumbnail_image = get_field( 'thumbnail_image' );
					$terms = get_the_terms( $portfolio->post->ID, 'portfolio_tag' );

					$term_name = array();
					$grid_classes = array( 'wow', 'fadeInUp' );
					if( $terms ) {
						foreach( $terms as $term ) {
							$grid_classes[] = $term->slug;
							$term_name[] = $term->name;
						}
					}

					$grid_classes = implode( ' ', $grid_classes );
					$term_name = implode( ',', $term_name );
					?>
                    <li class="<?php echo esc_attr( $grid_classes ); ?>">
                        <figure data-tilt>
                            <img src="<?php echo esc_url( $thumbnail_image ); ?>" alt="<?php the_title(); ?>" class="thumb" />
                            <figcaption>
                                <?php if( get_field( 'logo' ) ) { ?>
                                    <img src="<?php echo esc_url( get_field( 'logo' ) ); ?>" alt="<?php the_title(); ?>" class="brand" />
                                <?php } ?>
                                <h3><?php the_title(); ?></h3>

                                <?php if( $term_name !== '' ){ ?>
                                    <small><?php echo esc_html( $term_name ); ?></small>
                                <?php } ?>
                                <a href="<?php the_permalink(); ?>"><?php echo __( 'CASE DETAILS', 'unicord' ); ?></a>
                            </figcaption>
                        </figure>
                    </li>
					<?php
					$i++;
				endwhile;
				?>
                </ul>
            </div>
		<?php
		endif;

		wp_reset_query();
		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_portfolio",
	"name" 			    => __( 'Portfolio', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Total Count', 'unicord' ),
			"param_name" 	=> 	"total_count",
			"value"         => 6,
			"description"	=>	"Total number of portfolio items that will be shown.",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Column', 'unicord' ),
			"param_name" 	=> 	"column",
			"value"			=>	array(
				"Two"   => "two-cols",
				"Three" => "three-cols",
				"Four"  => "four-cols",
				"Five"  => "five-cols",
			),
			"group" 		=> 'General',
		),
	),
) );
