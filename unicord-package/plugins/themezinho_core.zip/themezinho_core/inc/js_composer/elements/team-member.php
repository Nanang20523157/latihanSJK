<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_team_member extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'total_count'		=> '5',
			'animate'			=> 'no',
			'animation_type'	=> '',
            'hover_image'       => ''
		), $atts ) );

		if( !is_int( $total_count ) ) {
			$total_count = 5;
		}
		ob_start();

		$wrapper_class = '';
		if( $animate == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}

		$args = array (
			'post_type'              => 'team',
			'posts_per_page'            => $total_count,
			'meta_query' => array(
			        array(
			         'key' => '_thumbnail_id',
			         'compare' => 'EXISTS'
			        ),
		    )
		);

		$hover_overlay_url = '';
		if ( $hover_image != '') {
			$hover_overlay_url = wp_get_attachment_url( $hover_image );
		}

		$teams = new WP_Query( $args );

		if ( $teams->have_posts() ) {
		    $uniqid = 'team-' . uniqid() . 'ed';
		    if( $hover_overlay_url ){
			?>
                <style>
                    #<?php echo esc_attr( $uniqid ); ?> figure:hover{
                        background: url(<?php echo esc_url( $hover_overlay_url ); ?>) center no-repeat cover !important;
                    }
                </style>
            <?php } ?>
			<div class="row <?php echo esc_attr( $wrapper_class ); ?>" id="<?php echo esc_attr( $uniqid ) ; ?>">
				<?php
				while ( $teams->have_posts() ) {
					$teams->the_post();
					$team_image = wp_get_attachment_url( get_post_thumbnail_id( $teams->post->ID ) );
					?>
                    <div class="col-lg-3 col-md-6">
                        <figure class="member"> <img src="<?php echo esc_url( $team_image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
                            <figcaption>
                                <h4><?php the_title(); ?></h4>
                                <?php if( get_field( 'designation' ) !== '' ) { ?>
                                    <small><?php the_field( 'designation' ); ?></small>
                                <?php } ?>
                            </figcaption>
                          </figure>
                    </div>
					<?php
				}
				?>
			</div>
			<?php
		} 
		wp_reset_postdata();

		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_team_member",
	"name" 			    => __( 'Team Members', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Total no of Post', 'unicord' ),
			"param_name" 	=> 	"total_count",
			"value" 	=> 	"5",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Hover Background Image', 'unicord' ),
			"param_name" 	=> 	"hover_image",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate",
			"group" 		=> 'General',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate", 'value' => 'yes'),
			"group" 		=> 'General',
			"value"			=>	motts_animations()
		)
	),
) );
