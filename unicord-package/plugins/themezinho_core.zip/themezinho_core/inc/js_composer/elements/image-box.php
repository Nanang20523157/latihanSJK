<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_image extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'		            => '',
			'image'			        => '',
			'class'			=> '0',
			'animate'		=> 'no',
			'animation_type'		=> '',
		), $atts ) );
		$image_url = '';
		if ( $image != '') {
			$image_url = wp_get_attachment_url( $image );
		}
		ob_start();

		$wrapper_class = '';
		if( $animate == 'yes' ) {
			$wrapper_class = 'wow ' . $animation_type;
		}

		if( $class ) {
			$wrapper_class .= $class;
		}

		if( $image_url !== '' ) {
			?>
			<div class="image-box <?php echo esc_attr( $wrapper_class ); ?>">
				<figure><img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"></figure>
			</div>
			<?php
		}

		return ob_get_clean();
	}
}


vc_map( array(
	"base" 			    => "ts_image",
	"name" 			    => __( 'Image Box', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Title', 'unicord' ),
			"param_name" 	=> 	"title",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"attach_image",
			"heading" 		=> 	__( 'Image', 'unicord' ),
			"param_name" 	=> 	"image",
			"group" 		=> 'General',
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animate', 'unicord' ),
			"param_name" 	=> 	"animate",
			"group" 		=> 'General',
			"value"			=>	array(
				"No"			=>		'no',
				"Yes"			=>		'yes',
			)
		),
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Animation Type', 'unicord' ),
			"param_name" 	=> 	"animation_type",
			"dependency" => array('element' => "animate", 'value' => 'yes'),
			"group" 		=> 'General',
			"value"			=>	motts_animations()
		),
		array(
			"type" 			=> 	"textfield",
			"heading" 		=> 	__( 'Class', 'unicord' ),
			"param_name" 	=> 	"class",
			"group" 		=> 'General',
		),
	),
) );
