<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_ts_hero_slider extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'hero_slider'		=> 0,
		), $atts ) );

//		 if( !is_int( $hero_slider ) ) {
//		 	return;
//		 }
		ob_start();
		$args = array (
			'post_type'		=> 'hero',
			'post__in'		=> array( $hero_slider )
	    );

		$the_query = new WP_Query( $args );
		if ( $the_query->have_posts() ) :
			while ( $the_query->have_posts() ) :
				$the_query->the_post();

				$hero_type = get_field( 'type' );
				if( $hero_type === 'swiper' ) :
		
		$background_image_responsive = ( get_field( 'background_image_responsive' ) ) ? get_field( 'background_image_responsive' ) : '';

					if( have_rows('slider') ):
                        $nav_previous_button_label = ( get_field( 'nav_previous_button_label' ) ) ? get_field( 'nav_previous_button_label' ) : __( 'PREV', 'unicord' );
                        $nav_next_button_label = ( get_field( 'nav_next_button_label' ) ) ? get_field( 'nav_next_button_label' ) : __( 'NEXT', 'unicord' );
                        $transition_speed = ( get_field( 'transition_speed' ) ) ? get_field( 'transition_speed' ) : 600;
                        $auto_play_delay = ( get_field( 'auto_play_delay' ) ) ? get_field( 'auto_play_delay' ) : 4500;
                        $loop = ( get_field( 'disable_loop' ) ) ? 'disable' : 'enable';
                        $page_number = ( get_field( 'disable_page_number' ) ) ? false : true;
                        $navigation = ( get_field( 'disable_navigation' ) ) ? false : true;

						$disable_social_icon = ( get_field( 'disable_social_icon' ) ) ? true : false;
						$disable_scroll_down = ( get_field( 'disable_scroll_down' ) ) ? true : false;
		
	                $background_image_responsive = get_sub_field( 'background_image_responsive' );
						?>
						<section class="header">
                            <div class="slider">
                                <div class="swiper-container gallery-top" data-speed="<?php echo esc_attr( $transition_speed ); ?>" data-autoplay-delay="<?php echo esc_attr( $auto_play_delay ); ?>" data-loop="<?php echo esc_attr( $loop ); ?>">
                                    <div class="swiper-wrapper">
                                        <?php
                                        while ( have_rows('slider') ) : the_row();
                                            $background_image = get_sub_field( 'background_image' );
                                            $background_image_responsive = get_sub_field( 'background_image_responsive' );
                                            ?>
                                            <div class="swiper-slide bg-image" data-background="<?php echo esc_url( $background_image ); ?>" data-stellar-background-ratio="0.5">
												<div class="responsive-slide bg-image" data-background="<?php echo esc_url( $background_image_responsive ); ?>" data-stellar-background-ratio="0.5"></div>
                                            </div>
                                            <?php
                                        endwhile;
                                        ?>
                                    </div>
                                    <?php if( $page_number ) { ?>
                                        <!-- Add Pagination -->
                                        <div class="swiper-pagination"></div>
                                    <?php } ?>
                                </div>

                                <div class="swiper-container gallery-thumbs" data-speed="<?php echo esc_attr( $transition_speed ); ?>" data-autoplay-delay="<?php echo esc_attr( $auto_play_delay ); ?>" data-loop="<?php echo esc_attr( $loop ); ?>">
                                    <div class="swiper-wrapper">
                                        <?php
                                        while ( have_rows('slider') ) : the_row();
                                            $background_image = get_sub_field( 'background_image' );
                                            ?>
                                            <div class="swiper-slide">
                                                <?php the_sub_field( 'title' ); ?>
                                                <a href="<?php the_sub_field( 'button_link' ); ?>"><?php the_sub_field( 'button_label' ); ?>
                                                    <div class="plus">+</div>
                                                </a>
                                            </div>
                                            <?php
                                        endwhile;
                                        ?>
                                    </div>
                                </div>

                            </div>
							<?php
							if( !$disable_social_icon ) {
								$social_media = unicord_get_option( 'social_media' );
								if ( count( $social_media ) ) {
									?>
                                    <ul class="social-media">
										<?php foreach ( $social_media as $social ) { ?>
                                            <li><a href="<?php echo esc_url( $social['url'] ); ?>"
                                                  ><i
                                                            class="<?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
										<?php } ?>
                                    </ul>
									<?php
								}
							}
							?>
							<?php

							if( !$disable_scroll_down ) {
								$scroll_down_label = unicord_get_option( 'scroll_down_label' );
								if( $scroll_down_label ) {
									?>
                                    <div class="scroll-down"><b><?php echo esc_html( $scroll_down_label ); ?></b><span></span></div>
									<?php
								}
							} ?>
				        </section>
						<?php

					endif;

				elseif( $hero_type === 'video' ) :
                    $background_video = ( get_field( 'background_video' ) ) ? get_field( 'background_video' ) : '';
                    $disable_social_icon = ( get_field( 'disable_social_icon' ) ) ? true : false;
                    $disable_scroll_down = ( get_field( 'disable_scroll_down' ) ) ? true : false;
                    if( $background_video ):
                    ?>
                        <section class="header">
                            <div class="video-hero">
                                <div class="video-bg">
                                    <video src="<?php echo esc_url( $background_video ); ?>" autoplay loop muted></video>
                                </div>
                                <!-- end video-bg -->
                                <div class="inner">
                                    <h1><?php the_field( 'title' ); ?></h1>
                                    <?php if( get_field( 'subtitle' ) ) { ?>
                                        <h5><?php the_field( 'subtitle' ); ?></h5>
                                    <?php } ?>

                                    <?php if( get_field( 'button_label' ) ) { ?>
                                        <a href="<?php echo esc_url( get_field( 'button_url' ) ); ?>"><?php the_field( 'button_label' ); ?></a>
                                    <?php } ?>
                                </div>
                                <!-- end inner -->
                            </div>
                            <!-- end video-hero -->

                            <?php
                            if( !$disable_social_icon ) {
                                $social_media = unicord_get_option( 'social_media' );
                                if ( count( $social_media ) ) {
                                    ?>
                                    <ul class="social-media">
                                        <?php foreach ( $social_media as $social ) { ?>
                                            <li><a href="<?php echo esc_url( $social['url'] ); ?>"
                                                   title="<?php echo esc_attr( $social['title'] ); ?>"><i
                                                            class="fa <?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
                                        <?php } ?>
                                    </ul>
                                    <?php
                                }
                            }
                            ?>
                            <?php

                            if( !$disable_scroll_down ) {
                                $scroll_down_label = unicord_get_option( 'scroll_down_label' );
                                if( $scroll_down_label ) {
                                    ?>
                                    <div class="scroll-down"><b><?php echo esc_html( $scroll_down_label ); ?></b><span></span></div>
                                    <?php
                                }
                            } ?>
                            <!-- end scroll-down -->
                        </section>
                        <?php
                    endif;
                elseif( $hero_type === 'particles' ):
	                $background_image = ( get_field( 'background_image' ) ) ? get_field( 'background_image' ) : '';
	                $disable_social_icon = ( get_field( 'disable_social_icon' ) ) ? true : false;
	                $disable_scroll_down = ( get_field( 'disable_scroll_down' ) ) ? true : false;
	                if( $background_image ):
		                ?>
                        <section class="header">
                            <div class="particles-mask" id="parallax">
                                <div class="inner">
                                    <div class="masker">
                                        <div class="layer" data-depth="0.2">
                                            <h1 data-text="<?php the_field( 'title' ); ?>"><?php the_field( 'title' ); ?></h1>
                                        </div>
                                        <!-- end layer -->
                                        <div id="particles-js"></div>
                                        <!-- end particles-js -->
                                    </div>
                                    <!-- end masker -->
                                    <?php if( get_field( 'subtitle' ) ) { ?>
                                        <h5><?php the_field( 'subtitle' ); ?></h5>
                                    <?php } ?>

                                    <?php if( get_field( 'button_label' ) ) { ?>
                                        <a href="<?php echo esc_url( get_field( 'button_url' ) ); ?>"><?php the_field( 'button_label' ); ?></a>
                                    <?php } ?>
                                </div>
                                <!-- end inner -->
                            </div>
                            <?php
			                if( !$disable_social_icon ) {
				                $social_media = unicord_get_option( 'social_media' );
				                if ( count( $social_media ) ) {
					                ?>
                                    <ul class="social-media">
						                <?php foreach ( $social_media as $social ) { ?>
                                            <li><a href="<?php echo esc_url( $social['url'] ); ?>"
                                                   title="<?php echo esc_attr( $social['title'] ); ?>"><i
                                                            class="fa <?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
						                <?php } ?>
                                    </ul>
					                <?php
				                }
			                }
			                ?>
			                <?php

			                if( !$disable_scroll_down ) {
				                $scroll_down_label = unicord_get_option( 'scroll_down_label' );
				                if( $scroll_down_label ) {
					                ?>
                                    <div class="scroll-down"><b><?php echo esc_html( $scroll_down_label ); ?></b><span></span></div>
					                <?php
				                }
			                } ?>
                            <!-- end scroll-down -->
                        </section>
	                <?php
	                endif;
				elseif( $hero_type === 'animation' ) :
					$background_image = ( get_field( 'background_image' ) ) ? get_field( 'background_image' ) : '';
					$background_color = ( get_field( 'background_color' ) ) ? get_field( 'background_color' ) : '#131313';
					$typography_image = ( get_field( 'typography_image' ) ) ? get_field( 'typography_image' ) : '';
					$disable_social_icon = ( get_field( 'disable_social_icon' ) ) ? true : false;
					$disable_scroll_down = ( get_field( 'disable_scroll_down' ) ) ? true : false;
					if( $background_image ):
					    $style = 'background:url(' . esc_url( $background_image ) . ') center no-repeat ' . $background_color . ';';

						?>
                        <section class="header">
                            <div class="animation-bg" id="parallax" style="<?php echo esc_attr( $style ); ?>">

                                <?php if( $typography_image ) { ?>
                                    <div class="inner layer" data-depth="0.7">
                                        <img src="<?php echo esc_url( $typography_image ); ?>" alt="" />
                                    </div>
                                <?php } ?>
                            </div>

							<?php
							if( !$disable_social_icon ) {
								$social_media = unicord_get_option( 'social_media' );
								if ( count( $social_media ) ) {
									?>
                                    <ul class="social-media">
										<?php foreach ( $social_media as $social ) { ?>
                                            <li><a href="<?php echo esc_url( $social['url'] ); ?>"
                                                   title="<?php echo esc_attr( $social['title'] ); ?>"><i
                                                            class="fa <?php echo esc_attr( $social['icon'] ); ?>"></i></a></li>
										<?php } ?>
                                    </ul>
									<?php
								}
							}
							?>
							<?php

							if( !$disable_scroll_down ) {
								$scroll_down_label = unicord_get_option( 'scroll_down_label' );
								if( $scroll_down_label ) {
									?>
                                    <div class="scroll-down"><b><?php echo esc_html( $scroll_down_label ); ?></b><span></span></div>
									<?php
								}
							} ?>
                            <!-- end scroll-down -->
                        </section>
					<?php
					endif;
				endif;

			endwhile;
		endif;

		wp_reset_postdata();

		return ob_get_clean();
	}
}

vc_map( array(
	"base" 			    => "ts_hero_slider",
	"name" 			    => __( 'Hero Slider', 'ts' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
	"content_element"   => true,
	"category" 		    => __('Unicord'),
	'params' => array(
		array(
			"type" 			=> 	"dropdown",
			"heading" 		=> 	__( 'Hero Slider', 'ts' ),
			"param_name" 	=> 	"hero_slider",
			"group" 		=> "General",
			"description"	=> __( 'Select the slider that you created in Hero Slider section. Check documentation for further detail.', 'ts' ),
			"value"			=>	ts_get_hero_slider()
		)
	),
) );
