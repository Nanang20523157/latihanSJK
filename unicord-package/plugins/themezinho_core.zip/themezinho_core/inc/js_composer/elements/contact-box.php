<?php
if ( !defined( 'ABSPATH' ) ) {
  die( '-1' );
}

class WPBakeryShortCode_tf_address extends WPBakeryShortCode {

  protected function content( $atts, $content = null ) {

    extract( shortcode_atts( array(
      'title' => '',
      'map_label' => __( 'Click here for Map', 'unicord' ),
      'iframe' => '',
      'longitude' => '',
      'description' => '',
      'animate_block' => 'false',
      'animation_type' => 'fadeIn',
      'animation_delay' => '',
      'have_map' => 'no'
    ), $atts ) );
    $map_pointer_url = '';
    if ( $map_pointer != '' ) {
      $map_pointer_url = wp_get_attachment_url( $map_pointer );
    }

    if ( $map_pointer_url === '' ) {
      $map_pointer_url = get_template_directory_uri() . '/images/map-pin.svg';
    }

    // enqueue google map
   
    ob_start();

    $wrapper_class = '';
    if ( $animate_block == 'yes' ) {
      $wrapper_class = 'wow ' . $animation_type;
    }
    ?>
<div class="contact-box <?php echo esc_attr( $wrapper_class ); ?>">
  <?php if( $title !== '' ) { ?>
  <span><?php echo esc_html( $title ); ?></span>
  <?php } ?>
  <?php echo wpb_js_remove_wpautop( $content, true ); ?>
  <?php if( $have_map == 'yes' ) { ?>
	<a href="<?php echo esc_attr( $iframe ); ?>" data-fancybox="" data-width="640" data-height="360" class="map-link"> <?php echo wp_kses_post( $map_label ); ?> </a>
	
  <?php } ?>
</div>
<?php

return ob_get_clean();
}
}

vc_map( array(
  "base" => "tf_address",
  "name" => __( 'Contact Box', 'unicord' ),
  "icon" => UNICORD_CORE_URI . "assets/img/custom.png",
  "content_element" => true,
  "category" => __( 'Unicord' ),
  'params' => array(
    array(
      "type" => "textfield",
      "heading" => __( 'Title', 'unicord' ),
      "param_name" => "title",
      "group" => 'General',
    ),
    array(
      "type" => "textarea_html",
      "heading" => __( 'Content', 'unicord' ),
      "param_name" => "content",
      "group" => 'General',
    ),

    array(
      "type" => "dropdown",
      "heading" => __( 'Have Map', 'unicord' ),
      "param_name" => "have_map",
      "group" => 'General',
      "value" => array(
        "No" => 'no',
        "Yes" => 'yes',
      )
    ),
    array(
      "type" => "textfield",
      "heading" => __( 'Map Link Label', 'unicord' ),
      "param_name" => "map_label",
      "dependency" => array( 'element' => "have_map", 'value' => 'yes' ),
      "group" => 'General',
    ),
    
    array(
      "type" => "textfield",
      "heading" => __( 'Iframe', 'unicord' ),
      "param_name" => "iframe",
      "dependency" => array( 'element' => "have_map", 'value' => 'yes' ),
      "group" => 'Google Map',
    ),
   
    array(
      "type" => "dropdown",
      "heading" => __( 'Animate', 'unicord' ),
      "param_name" => "animate_block",
      "group" => 'Animation',
      "value" => array(
        "No" => 'no',
        "Yes" => 'yes',
      )
    ),
    array(
      "type" => "dropdown",
      "heading" => __( 'Animation Type', 'unicord' ),
      "param_name" => "animation_type",
      "dependency" => array( 'element' => "animate_block", 'value' => 'yes' ),
      "group" => 'Animation',
      "value" => motts_animations()
    ),
    array(
      "type" => "textfield",
      "heading" => __( 'Animation Delay', 'unicord' ),
      "param_name" => "animation_delay",
      "dependency" => array( 'element' => "animate_block", 'value' => 'yes' ),
      "description" => __( 'Animation delay set in second e.g. 0.6s', 'unicord' ),
      "group" => 'Animation',
    )
  ),
) );
