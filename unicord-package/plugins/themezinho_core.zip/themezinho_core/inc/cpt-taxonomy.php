<?php

if ( ! function_exists('motts_portfolio_cpt') ) {

// Register Custom Post Type
	function motts_portfolio_cpt() {

		$labels = array(
			'name'                  => _x( 'Portfolios', 'Post Type General Name', 'unicord' ),
			'singular_name'         => _x( 'Portfolio', 'Post Type Singular Name', 'unicord' ),
			'menu_name'             => __( 'Portfolios', 'unicord' ),
			'name_admin_bar'        => __( 'Portfolio', 'unicord' ),
			'archives'              => __( 'Portfolio Archives', 'unicord' ),
			'attributes'            => __( 'Portfolio Attributes', 'unicord' ),
			'parent_item_colon'     => __( 'Parent Portfolio:', 'unicord' ),
			'all_items'             => __( 'All Portfolios', 'unicord' ),
			'add_new_item'          => __( 'Add New Portfolio', 'unicord' ),
			'add_new'               => __( 'Add New', 'unicord' ),
			'new_item'              => __( 'New Portfolio', 'unicord' ),
			'edit_item'             => __( 'Edit Portfolio', 'unicord' ),
			'update_item'           => __( 'Update Portfolio', 'unicord' ),
			'view_item'             => __( 'View Portfolio', 'unicord' ),
			'view_items'            => __( 'View Portfolios', 'unicord' ),
			'search_items'          => __( 'Search Portfolio', 'unicord' ),
			'not_found'             => __( 'Not found', 'unicord' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'unicord' ),
			'featured_image'        => __( 'Featured Image', 'unicord' ),
			'set_featured_image'    => __( 'Set featured image', 'unicord' ),
			'remove_featured_image' => __( 'Remove featured image', 'unicord' ),
			'use_featured_image'    => __( 'Use as featured image', 'unicord' ),
			'insert_into_item'      => __( 'Insert into Portfolio', 'unicord' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Portfolio', 'unicord' ),
			'items_list'            => __( 'Portfolios list', 'unicord' ),
			'items_list_navigation' => __( 'Portfolios list navigation', 'unicord' ),
			'filter_items_list'     => __( 'Filter Portfolios list', 'unicord' ),
		);
		$args = array(
			'label'                 => __( 'Portfolio', 'unicord' ),
			'description'           => __( 'Portfolio Description', 'unicord' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'thumbnail' ),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'             => 'dashicons-welcome-view-site',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => 'portfolio',
			'exclude_from_search'   => true,
			'publicly_queryable'    => true,
			'capability_type'       => 'page',
		);
		register_post_type( 'portfolio', $args );

	}
	add_action( 'init', 'motts_portfolio_cpt', 0 );

}

if ( ! function_exists( 'motts_portfolio_tag_taxonomy' ) ) {

// Register Custom Taxonomy
	function motts_portfolio_tag_taxonomy() {

		$labels = array(
			'name'                       => _x( 'Tags', 'Taxonomy General Name', 'unicord' ),
			'singular_name'              => _x( 'Tag', 'Taxonomy Singular Name', 'unicord' ),
			'menu_name'                  => __( 'Tags', 'unicord' ),
			'all_items'                  => __( 'All Tags', 'unicord' ),
			'parent_item'                => __( 'Parent Tag', 'unicord' ),
			'parent_item_colon'          => __( 'Parent Tag:', 'unicord' ),
			'new_item_name'              => __( 'New Tag Name', 'unicord' ),
			'add_new_item'               => __( 'Add New Tag', 'unicord' ),
			'edit_item'                  => __( 'Edit Tag', 'unicord' ),
			'update_item'                => __( 'Update Tag', 'unicord' ),
			'view_item'                  => __( 'View Tag', 'unicord' ),
			'separate_items_with_commas' => __( 'Separate tags with commas', 'unicord' ),
			'add_or_remove_items'        => __( 'Add or remove tags', 'unicord' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'unicord' ),
			'popular_items'              => __( 'Popular tags', 'unicord' ),
			'search_items'               => __( 'Search Tags', 'unicord' ),
			'not_found'                  => __( 'Not Found', 'unicord' ),
			'no_terms'                   => __( 'No tags', 'unicord' ),
			'items_list'                 => __( 'Tags list', 'unicord' ),
			'items_list_navigation'      => __( 'Tags list navigation', 'unicord' ),
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => false,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);
		register_taxonomy( 'portfolio_tag', array( 'portfolio' ), $args );

	}
	add_action( 'init', 'motts_portfolio_tag_taxonomy', 0 );

}

if ( ! function_exists('motts_hero_cpt') ) {

// Register Custom Post Type
	function motts_hero_cpt() {

		$labels = array(
			'name'                  => _x( 'Hero Banners', 'Post Type General Name', 'unicord' ),
			'singular_name'         => _x( 'Hero Banner', 'Post Type Singular Name', 'unicord' ),
			'menu_name'             => __( 'Hero Banners', 'unicord' ),
			'name_admin_bar'        => __( 'Hero Banner', 'unicord' ),
			'archives'              => __( 'Hero Banner Archives', 'unicord' ),
			'attributes'            => __( 'Hero Banner Attributes', 'unicord' ),
			'parent_item_colon'     => __( 'Parent Hero Banner:', 'unicord' ),
			'all_items'             => __( 'All Hero Banners', 'unicord' ),
			'add_new_item'          => __( 'Add New Hero Banner', 'unicord' ),
			'add_new'               => __( 'Add New', 'unicord' ),
			'new_item'              => __( 'New Hero Banner', 'unicord' ),
			'edit_item'             => __( 'Edit Hero Banner', 'unicord' ),
			'update_item'           => __( 'Update Hero Banner', 'unicord' ),
			'view_item'             => __( 'View Hero Banner', 'unicord' ),
			'view_items'            => __( 'View Hero Banners', 'unicord' ),
			'search_items'          => __( 'Search Hero Banner', 'unicord' ),
			'not_found'             => __( 'Not found', 'unicord' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'unicord' ),
			'featured_image'        => __( 'Featured Image', 'unicord' ),
			'set_featured_image'    => __( 'Set featured image', 'unicord' ),
			'remove_featured_image' => __( 'Remove featured image', 'unicord' ),
			'use_featured_image'    => __( 'Use as featured image', 'unicord' ),
			'insert_into_item'      => __( 'Insert into Hero Banner', 'unicord' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Hero Banner', 'unicord' ),
			'items_list'            => __( 'Hero Banners list', 'unicord' ),
			'items_list_navigation' => __( 'Hero Banners list navigation', 'unicord' ),
			'filter_items_list'     => __( 'Filter Hero Banners list', 'unicord' ),
		);
		$args = array(
			'label'                 => __( 'Hero Banner', 'unicord' ),
			'description'           => __( 'Hero Banner Description', 'unicord' ),
			'labels'                => $labels,
			'supports'              => array( 'title' ),
			'hierarchical'          => true,
			'public'                => false,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'             => 'dashicons-welcome-widgets-menus',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => false,
			'exclude_from_search'   => true,
			'publicly_queryable'    => false,
			'capability_type'       => 'page',
		);
		register_post_type( 'hero', $args );

	}
	add_action( 'init', 'motts_hero_cpt', 0 );

}

if ( ! function_exists('motts_team_cpt') ) {

// Register Custom Post Type
function motts_team_cpt() {

	$labels = array(
		'name'                  => _x( 'Team Members', 'Post Type General Name', 'unicord' ),
		'singular_name'         => _x( 'Team Member', 'Post Type Singular Name', 'unicord' ),
		'menu_name'             => __( 'Team Members', 'unicord' ),
		'name_admin_bar'        => __( 'Team Member', 'unicord' ),
		'archives'              => __( 'Team Archives', 'unicord' ),
		'attributes'            => __( 'Team Attributes', 'unicord' ),
		'parent_item_colon'     => __( 'Parent Team:', 'unicord' ),
		'all_items'             => __( 'All Team Members', 'unicord' ),
		'add_new_item'          => __( 'Add New Team Member', 'unicord' ),
		'add_new'               => __( 'Add New', 'unicord' ),
		'new_item'              => __( 'New Team Member', 'unicord' ),
		'edit_item'             => __( 'Edit Team Member', 'unicord' ),
		'update_item'           => __( 'Update Team Member', 'unicord' ),
		'view_item'             => __( 'View Team Member', 'unicord' ),
		'view_items'            => __( 'View Team Members', 'unicord' ),
		'search_items'          => __( 'Search Team Member', 'unicord' ),
		'not_found'             => __( 'Not found', 'unicord' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'unicord' ),
		'featured_image'        => __( 'Featured Image', 'unicord' ),
		'set_featured_image'    => __( 'Set featured image', 'unicord' ),
		'remove_featured_image' => __( 'Remove featured image', 'unicord' ),
		'use_featured_image'    => __( 'Use as featured image', 'unicord' ),
		'insert_into_item'      => __( 'Insert into Team', 'unicord' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'unicord' ),
		'items_list'            => __( 'Team Members list', 'unicord' ),
		'items_list_navigation' => __( 'Team Members list navigation', 'unicord' ),
		'filter_items_list'     => __( 'Filter Team Members list', 'unicord' ),
	);
	$args = array(
		'label'                 => __( 'Team Member', 'unicord' ),
		'description'           => __( 'Team Member Description', 'unicord' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => false,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-networking',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => true,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'team', $args );

}
add_action( 'init', 'motts_team_cpt', 0 );

}

add_filter( 'gettext','motts_team_member_custom_title' );

function motts_team_member_custom_title( $input ) {

    global $post_type;

    if( is_admin() && 'Enter title here' == $input && 'team' == $post_type )
        return 'Enter Team member full name';

    return $input;
}