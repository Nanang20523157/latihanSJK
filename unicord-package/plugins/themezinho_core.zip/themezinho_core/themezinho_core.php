<?php
/*
Plugin Name: Themezinho Core
Plugin URI: https://unicord.themezinho.net
Description: Unicord Theme Core Plugin
Author: Themezinho
Version: 1.1.1
Author URI: http://themezinho.net
*/

define( "UNICORD_CORE_PATH", plugin_dir_path( __FILE__ ) );
define( "UNICORD_CORE_URI", plugins_url( 'themezinho_core/' ) );

add_action( 'vc_before_init', 'unicord_vc_addons' );
/**
 * JS Composer Elements
 */

function unicord_vc_addons() {
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/section-title.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/icon-box.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/text-box.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/side-content.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/side-image-content.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/portfolio.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/client-logo.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/awards-box.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/team-member.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/hero-slider.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/contact-box.php';
  require_once UNICORD_CORE_PATH . '/inc/js_composer/elements/image-box.php';
}

require_once UNICORD_CORE_PATH . '/inc/js_composer/vc_extra_params.php';

/**
 * Include advanced custom field
 */
// 1. customize ACF path
add_filter( 'acf/settings/path', 'my_acf_settings_path' );

function unicord_acf_settings_path( $path ) {
  $path = UNICORD_CORE_PATH . '/inc/acf/';

  return $path;
}


// 2. customize ACF dir
add_filter( 'acf/settings/dir', 'unicord_acf_settings_dir' );

function unicord_acf_settings_dir( $dir ) {
  $dir = UNICORD_CORE_URI . '/inc/acf/';

  return $dir;
}

//Hide ACF field group menu item
add_filter( 'acf/settings/show_admin', '__return_false' );
require UNICORD_CORE_PATH . '/inc/acf/acf.php';

require_once UNICORD_CORE_PATH . '/inc/theme-options.php';

require_once UNICORD_CORE_PATH . '/inc/cpt-taxonomy.php';

// default options
function unicord_after_import() {

  update_field( 'enable_preloader', 1, 'option' );
  update_field( 'pre_loader_wrapper_bg_color', '#000000', 'option' );
  update_field( 'pre_loader_bg_size', '80px 80px', 'option' );

  // preloader text
  $preloader_text = array(
    array( 'title' => esc_html__( 'Please wait', 'unicord' ) ),
    array( 'title' => esc_html__( 'Still loading', 'unicord' ) ),
    array( 'title' => esc_html__( 'Almost done', 'unicord' ) ),
  );
  update_field( 'pre_loader_text_rotater', $preloader_text, 'option' );


  // social media
  $social_media = array(
    array(
      'title' => esc_html__( 'Facebook', 'unicord' ),
      'url' => '#',
      'icon' => 'fab fa-facebook-f'
    ),
    array(
      'title' => esc_html__( 'Twitter', 'unicord' ),
      'url' => '#',
      'icon' => 'fab fa-twitter'
    ),
    array(
      'title' => esc_html__( 'Behance', 'unicord' ),
      'url' => '#',
      'icon' => 'fab fa-behance'
    ),
    array(
      'title' => esc_html__( 'Youtube', 'unicord' ),
      'url' => '#',
      'icon' => 'fab fa-youtube'
    ),
  );
  update_field( 'social_media', $social_media, 'option' );

  update_field( 'nav_menu_type', 'hamburger', 'option' );
  update_field( 'archive_show_sidebar', 'no', 'option' );
  update_field( 'archive_strip_content', 'yes', 'option' );
  update_field( 'footer_show_social_links', 1, 'option' );
  update_field( 'show_call_to_action', 1, 'option' );

  update_field( 'footer_cta_tagline_title', wp_kses_post( "Don't be shy and<br>talk to us?" ), 'option' );
  update_field( 'footer_cta_subtitle', 'Say hello@unicord.com.ua', 'option' );

  $menu_address = "Contornio Ave Kunsgatan 4<br>41247 Luxembord<br>074-753 5875";
  update_field( 'menu_address', wp_kses_post( $menu_address ), 'option' );

  update_field( 'enable_scroll_down', 1, 'option' );
  update_field( 'scroll_down_label', esc_html__( 'SCROLL DOWN', 'unicord' ), 'option' );

  update_field( 'show_email', 1, 'option' );
  update_field( 'email_label', esc_html__( 'Say', 'unicord' ), 'option' );
  update_field( 'email_address', wp_kses_post( '<span>hello</span>@unicord.com' ), 'option' );
}

function motts_animations() {

  return array(
    'bounce' => 'bounce',
    'flash' => 'flash',
    'pulse' => 'pulse',
    'rubberBand' => 'rubberBand',
    'shake' => 'shake',
    'headShake' => 'headShake',
    'swing' => 'swing',
    'tada' => 'tada',
    'wobble' => 'wobble',
    'jello' => 'jello',
    'bounceIn' => 'bounceIn',
    'bounceInDown' => 'bounceInDown',
    'bounceInLeft' => 'bounceInLeft',
    'bounceInRight' => 'bounceInRight',
    'bounceInUp' => 'bounceInUp',
    'bounceOut' => 'bounceOut',
    'bounceOutDown' => 'bounceOutDown',
    'bounceOutLeft' => 'bounceOutLeft',
    'bounceOutRight' => 'bounceOutRight',
    'bounceOutUp' => 'bounceOutUp',
    'fadeIn' => 'fadeIn',
    'fadeInDown' => 'fadeInDown',
    'fadeInDownBig' => 'fadeInDownBig',
    'fadeInLeft' => 'fadeInLeft',
    'fadeInLeftBig' => 'fadeInLeftBig',
    'fadeInRight' => 'fadeInRight',
    'fadeInRightBig' => 'fadeInRightBig',
    'fadeInUp' => 'fadeInUp',
    'fadeInUpBig' => 'fadeInUpBig',
    'fadeOut' => 'fadeOut',
    'fadeOutDown' => 'fadeOutDown',
    'fadeOutDownBig' => 'fadeOutDownBig',
    'fadeOutLeft' => 'fadeOutLeft',
    'fadeOutLeftBig' => 'fadeOutLeftBig',
    'fadeOutRight' => 'fadeOutRight',
    'fadeOutRightBig' => 'fadeOutRightBig',
    'fadeOutUp' => 'fadeOutUp',
    'fadeOutUpBig' => 'fadeOutUpBig',
    'flipInX' => 'flipInX',
    'flipInY' => 'flipInY',
    'flipOutX' => 'flipOutX',
    'flipOutY' => 'flipOutY',
    'lightSpeedIn' => 'lightSpeedIn',
    'lightSpeedOut' => 'lightSpeedOut',
    'rotateIn' => 'rotateIn',
    'rotateInDownLeft' => 'rotateInDownLeft',
    'rotateInDownRight' => 'rotateInDownRight',
    'rotateInUpLeft' => 'rotateInUpLeft',
    'rotateInUpRight' => 'rotateInUpRight',
    'rotateOut' => 'rotateOut',
    'rotateOutDownLeft' => 'rotateOutDownLeft',
    'rotateOutDownRight' => 'rotateOutDownRight',
    'rotateOutUpLeft' => 'rotateOutUpLeft',
    'rotateOutUpRight' => 'rotateOutUpRight',
    'hinge' => 'hinge',
    'jackInTheBox' => 'jackInTheBox',
    'rollIn' => 'rollIn',
    'rollOut' => 'rollOut',
    'zoomIn' => 'zoomIn',
    'zoomInDown' => 'zoomInDown',
    'zoomInLeft' => 'zoomInLeft',
    'zoomInRight' => 'zoomInRight',
    'zoomInUp' => 'zoomInUp',
    'zoomOut' => 'zoomOut',
    'zoomOutDown' => 'zoomOutDown',
    'zoomOutLeft' => 'zoomOutLeft',
    'zoomOutRight' => 'zoomOutRight',
    'zoomOutUp' => 'zoomOutUp',
    'slideInDown' => 'slideInDown',
    'slideInLeft' => 'slideInLeft',
    'slideInRight' => 'slideInRight',
    'slideInUp' => 'slideInUp',
    'slideOutDown' => 'slideOutDown',
    'slideOutLeft' => 'slideOutLeft',
    'slideOutRight' => 'slideOutRight',
    'slideOutUp' => 'slideOutUp',
    'heartBeat' => 'heartBeat'
  );
}


function ts_get_hero_slider() {
  $args = array(
    'post_type' => 'hero',
    'posts_per_page' => -1,
  );
  $sliders = get_posts( $args );

  $_slider = array();

  if ( count( $sliders ) ) {
    foreach ( $sliders as $slider ) {
      $_slider[ $slider->ID . ' ' . $slider->post_title ] = $slider->ID;
    }
  }

  return $_slider;
}